class BooksController < ApplicationController
    #index
    def index
        @books = Book.all
    end

    #show -get
    def show
        @book = Book.find(params[:id])
    end

    #new - get
    def new
        @book = Book.new
    end

    #create - post
    def create
        @book = Book.new(resources_params)
        if @book.save
            redirect_to books_path
        else
            render 'new'
        end
    end

    #edit - get
    def edit
        @book = Book.find(params[:id])

    end

    #update - patch/put
    def update
       @book = Book.find(params[:id]) 
       @book.update(resources_params)
       redirect_to books_path
    end

    #destroy
    def destroy
        book = Book.find(params[:id])
        book.destroy
        redirect_to books_path
    end

    def state
        @books = Book.where(status: 0)
        render 'index'
    end

    def borrowBook
        @book = Book.find(params[:id])
        @book.status = 0
        @book.save
        redirect_to books_path
    end

    def returnBook
        @book = Book.find(params[:id])
        @book.status = 1
        @book.save
        redirect_to books_path, notice: "Book has been return"
    end

    private

    def resources_params
        params.require(:book).permit(:title, :isbn, :page, :year, :author, :stock)
        
    end
end
