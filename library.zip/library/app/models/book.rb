class Book < ApplicationRecord
    validates :title, presence: true
    validates :isbn, presence: true, numericality: true
    validates :page, presence: true, numericality: true
    validates :year, presence: true, numericality: true
    validates :author, presence: true
    validates :stock, presence: true, numericality: true
end
