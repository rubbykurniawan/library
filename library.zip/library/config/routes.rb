Rails.application.routes.draw do
  
  root 'sessions#new'
  resources :users
  resources :sessions, only: [:new, :create, :destroy]
  
  get 'signup', to: 'users#new', as: 'signup'
  get 'login', to: 'sessions#new', as: 'login' 
  get 'logout', to: 'sessions#destroy', as: 'logout'
  
  # get '/books', to: 'books#index'
  # get '/books/:id', to: 'books#show'
  # get '/books/new', to: 'books#new'
  # get '/books', to: 'books#create'
  # get '/books/state', to: 'books#state'
  
  resources :books do
    get :state, on: :collection
    patch :borrowBook, on: :member
    patch :returnBook, on: :member
  end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
